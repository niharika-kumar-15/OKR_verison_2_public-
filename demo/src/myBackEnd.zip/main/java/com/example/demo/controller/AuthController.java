package com.example.demo.controller;

import com.example.demo.Jwt.JwtResponse;
import com.example.demo.Jwt.LoginRequest;
import com.example.demo.Jwt.MessageResponse;
import com.example.demo.Security.JwtUtils;
import com.example.demo.model.User;
import com.example.demo.enums.Role;  // Import the Role enum
import com.example.demo.repository.UserRepository;
import com.example.demo.service.SmtpGmailSenderService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtUtils jwtUtils;

    @Autowired
    private SmtpGmailSenderService emailService;

    @PostMapping("/login")
    public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginRequest loginRequest) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(loginRequest.getEmail(), null));
        SecurityContextHolder.getContext().setAuthentication(authentication);
        String jwt = jwtUtils.generateJwtToken(authentication);
        UserDetails userDetails = (UserDetails) authentication.getPrincipal();
        User user = userRepository.findByEmail(userDetails.getUsername());

        Set<String> roles = user.getUserRoles().stream()
                .map(userRole -> "ROLE_" + userRole.getRole().name())
                .collect(Collectors.toSet());

        return ResponseEntity.ok(new JwtResponse(
                jwt,
                user.getUserId(),
                user.getUsername(),
                user.getEmail(),
                roles));
    }

    @PostMapping("/send-otp")
    public ResponseEntity<?> sendOtp(@RequestBody LoginRequest loginRequest) {
        if (!userRepository.existsByEmail(loginRequest.getEmail())) {
            return ResponseEntity.badRequest().body(new MessageResponse("Error: Please use an authorized email ID."));
        }
        String otp = generateOtp();
        emailService.sendEmail(loginRequest.getEmail(), "OKR-Verification OTP", "Your OTP is: " + otp);
        return ResponseEntity.ok(Map.of("success", true, "message", "OTP sent to your email."));
    }

    private String generateOtp() {
        return String.format("%06d", (int) (Math.random() * 1000000));
    }
}
