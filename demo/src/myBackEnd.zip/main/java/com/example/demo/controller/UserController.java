package com.example.demo.controller;

import com.example.demo.model.User;
import com.example.demo.enums.Role;  // Import Role enum
import com.example.demo.service.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("api/users")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PatchMapping("/{userId}/role")
    public ResponseEntity<User> updateUserRole(@PathVariable Long userId, @RequestParam String role) {
        User user = userService.getUserById(userId);
        if (user == null) {
            return ResponseEntity.notFound().build();
        }

        Role enumRole = Role.fromString(role); // Use the Role enum to get the correct role
        user.setRoles(enumRole);  // Set the role using the enum value

        User updatedUser = userService.updateUser(user);
        return ResponseEntity.ok(updatedUser);
    }
}
